import random
from urllib.parse import urlencode
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import requests
from selenium.webdriver.support.ui import Select
import pandas as pd
import asyncio
from selenium.webdriver import Keys
import subprocess
import os
from unidecode import unidecode
def remove_diacritics(input_str):
    return unidecode(input_str)

ceo_not_found=[]
url_not_found=[]
all_companies=[]
def ceo(search,website_name,website_url):
    try:
        company=search
        if search.endswith(".") or search.endswith(". ") or search.endswith(" ."):
            search = search[:-1]
            search = search.replace(". ", "")
            search = search.replace(" .", "")
        else:
            search = search.replace(". ", "-")
            search = search.replace(" .", "-")
            search = search.replace(".", "-").lower()
        if search.endswith(".ai"):
            search = search.replace(".ai", "-ai")
        search = search.replace(".", "-").lower()
        search = search.replace(" inc", "")
        search = search.replace(".io", "")
        search = search.replace(".co", "")
        search = search.replace("- ", "-")
        search = search.replace(" -", "-")
        search = search.replace(" ", "-")
        search = search.replace("labs", "")
        # print(search)


        url = requests.get(f"https://theorg.com/org/{search}")
        bs = BeautifulSoup(url.text, "html.parser")

        ceo_div = bs.find('div', class_='PositionCard_role__7IloA')
        ceo_name_span = ceo_div.find_previous_sibling('a').find('span',class_='PositionCard_name__kF7sr') if ceo_div else None
        ceo_name = ceo_name_span.text if ceo_name_span else "CEO none"
        ceo=ceo_name

        ceo_name = remove_diacritics(ceo_name)
        # print(f"CEO Name: {ceo_name}")
        ceo_low = ceo_name.lower()

        if ceo_low.endswith("."):
            ceo_low = ceo_low[:-1]
        ceo_low = ceo_low.replace("."," ")
        ceo_low=ceo_low.replace(" ", "-")
        ceo_low = ceo_low.replace(",","-")
        ceo_low=ceo_low.replace("--","-")
        # print(ceo_low)

        url_id = requests.get(f"https://theorg.com/org/{search}/org-chart/{ceo_low}")
        bs1 = BeautifulSoup(url_id.text, "html.parser")
        link = bs1.find('a', class_="sc-fd53c065-1 JGmoX")


        if ceo_name != "CEO none":
             if link is not None:
                 href_value = link.get('href')
                 # print(f"CEO URL: {href_value}")

             else:

                 ceo = ceo.replace(" ", "+")
                 API_KEY1 ='518b7afa-0c27-48a6-bbf5-78cca0442d13'
                 url = f'https://www.google.com/search?q={ceo}+linkedin+profile'
                 proxy_params = {
                     'api_key': API_KEY1,
                     'url': url,
                 }
                 response = requests.get(
                     url='https://proxy.scrapeops.io/v1/',
                     params=urlencode(proxy_params),
                     timeout=10,
                 )
                 response.raise_for_status()
                 soup = BeautifulSoup(response.text, 'html.parser')
                 link_tag = soup.find('a', {'jsname': 'UWckNb'})

                 href_value = link_tag.get('href')


        else:
            url = f'https://www.google.com/search?q={search}+CEO+linkedin+profile+current'
            API_KEY2 = 'fb081e9e-dd24-4c8a-adf0-f55b67955cf2'


            proxy_params = {
                'api_key': API_KEY2,
                'url': url,
            }
            response = requests.get(
                url='https://proxy.scrapeops.io/v1/',
                params=urlencode(proxy_params),
                timeout=10
            )
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            link_tag = soup.find('a', {'jsname': 'UWckNb'})

            href_value = link_tag.get('href')
            h3_tags = soup.find('h3', class_='LC20lb MBeuO DKV0Md')
            ceo_name += h3_tags.text
            ceo_name=ceo_name.replace("CEO none","")
            ceo_name = ceo_name.split('-')[0]


        if company != ceo_name:
            all_companies.append({
                "Company Name":company,
                "Website Name(Domain)":website_name,
                "Website Url":website_url,
                "cloud":"amazon web services",
                "CEO": ceo_name,
                "LinkedIn": href_value
                # "linked in url:",
            })
            # print(website_url)
            # print(ceo_name)
            # print(website_name)
            print(href_value)
    except Exception as e:
        print(f"An error occurred: {e}")



def open_excel(filename,column_name,w_name,w_url):
    file_path=os.path.join(os.getcwd(),filename)

    if os.path.exists(file_path):
        try:
            subprocess.Popen(['start', 'excel',file_path],shell=True)
            df=pd.read_excel(file_path)
            if column_name in df.columns:
                for index,value in df[column_name].items():
                    website_name = df.at[index,w_name]
                    website_url=df.at[index,w_url]
                    print(value)
                    ceo(value,website_name,website_url)

            else:
                print("col not found")
        except Exception as e:
            print(f"Error reading in the excel file : {e}")
    else:
        print(f"the file {filename} does not exist")


def main():
    open_excel("amazon web services.xlsx","Company Name","Website Name(Domain)","Website Url")


if __name__=="__main__":
    main()
    df = pd.DataFrame(all_companies)
    df.to_excel("amazonceo.xlsx", index=False)
    # ceo("Bedrock Data by design")